<div class="row">
    <div class="col-xl-12 order-xl-1">
        
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-8">
                         <h3 class="mb-0">GST Regitration </h3>
                    </div>
                </div>
            </div>
            
            <div class="card-body">

                <div class="pl-lg-6">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Select Comapany Type</label>
                                <select name="com_type" id="com_type" class="form-control"  required>
                                    <option value="">Select Company Type</option>
                                    <option value="privatelimited">Private limited</option>
                                    <option value="Partenership">Partenership</option>
                                    <option value="Proprietorship">Proprietorship</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div id="addpvtltdForm"></div>
                        </div>
                    </div>
                
                </div>

             
            </div>

        </div>
     </div>
 </div>

