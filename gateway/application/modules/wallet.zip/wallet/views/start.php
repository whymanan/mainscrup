
                    <div class="row">
        <div class="col-xl-3">
          <!--* Card header *-->
          <!--* Card body *-->
          <!--* Card init *-->
          
        </div>
        <div class="col-xl-6">
          <!--* Card header *-->
          <!--* Card body *-->
          <!--* Card init *-->
          <div class="card">
            <!-- Card header -->
            <div class="card-header">
              <!-- Surtitle -->
              <h6 class="surtitle text-center">Start Wallet</h6>
              <!-- Title -->
             
            </div>
            <!-- Card body -->
            <div class="card-body text-center">
             <a class="link " href="<?php echo base_url('wallet/add_wallet')?>">Start Wallet</a>
            </div>
          </div>
        </div>
        <div class="col-xl-3">
          <!--* Card header *-->
          <!--* Card body *-->
          <!--* Card init *-->
        
        </div>
      </div>
    
     
    </div>
  </div>
</div>
